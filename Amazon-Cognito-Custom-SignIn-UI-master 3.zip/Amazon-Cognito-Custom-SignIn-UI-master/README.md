# Amazon-Cognito-Custom-SignIn-UI
This is a sample app to show how to customise the AWS Cognito SignInActivity view of a mobile app. 
It gives detail of the activities needed to modify for the customisation. 

Screenshots
-------------

<img src="screenshots/screens.png" height="430" alt="Screenshot"/> 
