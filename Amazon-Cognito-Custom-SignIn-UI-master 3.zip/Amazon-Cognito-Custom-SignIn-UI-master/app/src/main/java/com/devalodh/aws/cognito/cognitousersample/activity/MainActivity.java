package com.devalodh.aws.cognito.cognitousersample.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import android.widget.TextView;

import com.devalodh.aws.cognito.cognitousersample.R;
import com.devalodh.aws.cognito.cognitousersample.utils.AppHelper;

/**
 * Created by devashish on 02/02/18
 */

public class MainActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.activity_main);
        TextView userName = (TextView) findViewById(R.id.usernameTxtview);
        if (AppHelper.getItemCount()>0) {
            userName.setText(String.format(" Welcome %s!",AppHelper.getItemForDisplay(0).getDataText()));
        }
    }
}
